/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/add.ts":
/*!********************!*\
  !*** ./src/add.ts ***!
  \********************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

eval("\nObject.defineProperty(exports, \"__esModule\", ({ value: true }));\nexports.addContact = addContact;\nvar util_1 = __webpack_require__(/*! ./util */ \"./src/util.ts\");\nvar contact_1 = __webpack_require__(/*! ./contact */ \"./src/contact.ts\");\nfunction addContact(name, email, contacts) {\n    var id = (0, util_1.gunretUniqueId)();\n    var newContact = new contact_1.Contact(name, email, id);\n    contacts.push(newContact);\n}\n\n\n//# sourceURL=webpack://contact-maneger/./src/add.ts?");

/***/ }),

/***/ "./src/app.ts":
/*!********************!*\
  !*** ./src/app.ts ***!
  \********************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

eval("\nObject.defineProperty(exports, \"__esModule\", ({ value: true }));\nvar render_1 = __webpack_require__(/*! ./render */ \"./src/render.ts\");\nvar add_1 = __webpack_require__(/*! ./add */ \"./src/add.ts\");\nvar update_1 = __webpack_require__(/*! ./update */ \"./src/update.ts\");\nvar storage_1 = __webpack_require__(/*! ./storage */ \"./src/storage.ts\");\nvar contacts;\ncontacts = (0, storage_1.readContact)();\nvar addContactForm = document.getElementById(\"add-contact-form\");\naddContactForm.addEventListener(\"submit\", function (event) {\n    event.preventDefault();\n    var nameInput = document.getElementById(\"name\");\n    var emailInput = document.getElementById(\"email\");\n    var idlInput = document.getElementById(\"id\");\n    if (idlInput.value === \"\" || idlInput.value === undefined) {\n        (0, add_1.addContact)(nameInput.value, emailInput.value, contacts);\n    }\n    else {\n        (0, update_1.updateContact)(idlInput.value, nameInput.value, emailInput.value, contacts);\n    }\n    (0, storage_1.saveContact)(contacts);\n    (0, render_1.renderContacts)(contacts);\n    idlInput.value = \"\";\n    nameInput.value = \"\";\n    emailInput.value = \"\";\n});\n(0, render_1.renderContacts)(contacts);\n\n\n//# sourceURL=webpack://contact-maneger/./src/app.ts?");

/***/ }),

/***/ "./src/contact.ts":
/*!************************!*\
  !*** ./src/contact.ts ***!
  \************************/
/***/ ((__unused_webpack_module, exports) => {

eval("\nObject.defineProperty(exports, \"__esModule\", ({ value: true }));\nexports.Contact = void 0;\nvar Contact = /** @class */ (function () {\n    function Contact(name, email, id) {\n        this.name = name;\n        this.email = email;\n        this.id = id;\n    }\n    return Contact;\n}());\nexports.Contact = Contact;\n\n\n//# sourceURL=webpack://contact-maneger/./src/contact.ts?");

/***/ }),

/***/ "./src/delete.ts":
/*!***********************!*\
  !*** ./src/delete.ts ***!
  \***********************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

eval("\nObject.defineProperty(exports, \"__esModule\", ({ value: true }));\nexports.deleteContact = deleteContact;\nvar render_1 = __webpack_require__(/*! ./render */ \"./src/render.ts\");\nvar storage_1 = __webpack_require__(/*! ./storage */ \"./src/storage.ts\");\nfunction deleteContact(id, contacts) {\n    contacts = contacts.filter(function (contact) { return contact.id !== id; });\n    (0, storage_1.saveContact)(contacts);\n    (0, render_1.renderContacts)(contacts);\n}\n\n\n//# sourceURL=webpack://contact-maneger/./src/delete.ts?");

/***/ }),

/***/ "./src/edit.ts":
/*!*********************!*\
  !*** ./src/edit.ts ***!
  \*********************/
/***/ ((__unused_webpack_module, exports) => {

eval("\nObject.defineProperty(exports, \"__esModule\", ({ value: true }));\nexports.editContact = editContact;\nfunction editContact(id, contacts) {\n    var index = contacts.findIndex(function (contact) { return contact.id === id; });\n    var idInput = document.getElementById(\"id\");\n    var nameInput = document.getElementById(\"name\");\n    var emailInput = document.getElementById(\"email\");\n    idInput.value = contacts[index].id;\n    nameInput.value = contacts[index].name;\n    emailInput.value = contacts[index].email;\n}\n\n\n//# sourceURL=webpack://contact-maneger/./src/edit.ts?");

/***/ }),

/***/ "./src/render.ts":
/*!***********************!*\
  !*** ./src/render.ts ***!
  \***********************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

eval("\nObject.defineProperty(exports, \"__esModule\", ({ value: true }));\nexports.renderContacts = renderContacts;\nvar delete_1 = __webpack_require__(/*! ./delete */ \"./src/delete.ts\");\nvar edit_1 = __webpack_require__(/*! ./edit */ \"./src/edit.ts\");\nvar storage_1 = __webpack_require__(/*! ./storage */ \"./src/storage.ts\");\nfunction renderContacts(contacts) {\n    contacts = (0, storage_1.readContact)();\n    var contactList = document.getElementById(\"contact-list\");\n    contactList.innerHTML = \"\";\n    contacts.forEach(function (contact) {\n        var listitem = document.createElement(\"li\");\n        listitem.textContent = \"\".concat(contact.name, \" (\").concat(contact.email, \")\");\n        var editButton = document.createElement(\"button\");\n        editButton.innerHTML = \"Edit\";\n        editButton.onclick = function () { return (0, edit_1.editContact)(contact.id, contacts); };\n        var deleteButton = document.createElement(\"button\");\n        deleteButton.innerHTML = \"Delete\";\n        deleteButton.onclick = function () { return (0, delete_1.deleteContact)(contact.id, contacts); };\n        contactList.appendChild(listitem);\n        contactList.appendChild(deleteButton);\n        contactList.appendChild(editButton);\n    });\n}\n\n\n//# sourceURL=webpack://contact-maneger/./src/render.ts?");

/***/ }),

/***/ "./src/storage.ts":
/*!************************!*\
  !*** ./src/storage.ts ***!
  \************************/
/***/ ((__unused_webpack_module, exports) => {

eval("\nObject.defineProperty(exports, \"__esModule\", ({ value: true }));\nexports.saveContact = saveContact;\nexports.readContact = readContact;\nfunction saveContact(contacts) {\n    localStorage.setItem(\"contacts\", JSON.stringify(contacts));\n}\nfunction readContact() {\n    var contacts = JSON.parse(localStorage.getItem(\"contacts\"));\n    if (contacts != null) {\n        return contacts;\n    }\n    return [];\n}\n\n\n//# sourceURL=webpack://contact-maneger/./src/storage.ts?");

/***/ }),

/***/ "./src/update.ts":
/*!***********************!*\
  !*** ./src/update.ts ***!
  \***********************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

eval("\nvar __assign = (this && this.__assign) || function () {\n    __assign = Object.assign || function(t) {\n        for (var s, i = 1, n = arguments.length; i < n; i++) {\n            s = arguments[i];\n            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))\n                t[p] = s[p];\n        }\n        return t;\n    };\n    return __assign.apply(this, arguments);\n};\nObject.defineProperty(exports, \"__esModule\", ({ value: true }));\nexports.updateContact = updateContact;\nvar contact_1 = __webpack_require__(/*! ./contact */ \"./src/contact.ts\");\nfunction updateContact(id, name, email, contacts) {\n    var index = contacts.findIndex(function (contact) { return contact.id === id; });\n    var updateContact = new contact_1.Contact(name, email, id);\n    if (index != -1) {\n        contacts[index] = __assign(__assign({}, contacts[index]), updateContact);\n    }\n}\n\n\n//# sourceURL=webpack://contact-maneger/./src/update.ts?");

/***/ }),

/***/ "./src/util.ts":
/*!*********************!*\
  !*** ./src/util.ts ***!
  \*********************/
/***/ ((__unused_webpack_module, exports) => {

eval("\nObject.defineProperty(exports, \"__esModule\", ({ value: true }));\nexports.gunretUniqueId = gunretUniqueId;\nfunction gunretUniqueId() {\n    return Date.now().toString(36) + Math.random().toString(36).substr(2);\n}\n\n\n//# sourceURL=webpack://contact-maneger/./src/util.ts?");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = __webpack_require__("./src/app.ts");
/******/ 	
/******/ })()
;
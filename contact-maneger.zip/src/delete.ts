import { Contact } from "./contact";
import { renderContacts } from "./render";
import { saveContact } from "./storage";
export function deleteContact(id:string,contacts:Contact[]):void{
   contacts = contacts.filter(contact=>contact.id!==id);
   saveContact(contacts);
renderContacts(contacts);
}
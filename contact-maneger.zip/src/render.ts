import {Contact} from "./contact";
import { deleteContact } from "./delete";
import { editContact } from "./edit";
import { readContact } from "./storage";
export function renderContacts(contacts : Contact[]){
    contacts= readContact();
const contactList = document.getElementById("contact-list") as HTMLUListElement;
contactList.innerHTML="";
contacts .forEach(contact => {
    const listitem = document.createElement("li");
    listitem.textContent = `${contact.name} (${contact.email})`;

    const editButton = document.createElement("button");
    editButton.innerHTML = "Edit";
    editButton.onclick = ()=> editContact(contact.id,contacts);

    const deleteButton = document.createElement("button");
    deleteButton.innerHTML = "Delete";
    deleteButton.onclick = ()=> deleteContact(contact.id,contacts);

    contactList.appendChild(listitem);
    contactList.appendChild(deleteButton);
    contactList.appendChild(editButton);
});
}
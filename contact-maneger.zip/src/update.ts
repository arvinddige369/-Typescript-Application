import { Contact } from "./contact";
export function updateContact(id:string, name:string, email:string, contacts : Contact[]): void{
    const index = contacts.findIndex(contact=>contact.id===id);
    const updateContact = new Contact(name, email, id);
    if(index != -1){
contacts[index] = {...contacts[index], ...updateContact};
    }
}
import {Contact} from "./contact";
import { renderContacts } from "./render";
import { addContact } from "./add";
import { updateContact } from "./update";
import { readContact,saveContact } from "./storage";
let contacts : Contact[];
contacts=readContact();

const addContactForm = document.getElementById("add-contact-form") as HTMLFormElement;
addContactForm.addEventListener("submit",(event)=>{
    event.preventDefault();
    const nameInput = document.getElementById("name") as HTMLInputElement;
    const emailInput = document.getElementById("email") as HTMLInputElement;
    const idlInput = document.getElementById("id") as HTMLInputElement;
    if(idlInput.value === "" || idlInput.value === undefined){
        addContact(nameInput.value,emailInput.value,contacts);
    }else{
        updateContact(idlInput.value,nameInput.value,emailInput.value,contacts);
    }
saveContact(contacts);
    renderContacts(contacts);
    idlInput.value = "";
    nameInput.value = "";
    emailInput.value = "";
})
renderContacts(contacts);
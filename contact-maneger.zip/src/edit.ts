import { Contact } from "./contact";
export function editContact( id : string, contacts : Contact[]) : void{
    const index = contacts.findIndex(contact =>contact.id===id);
    const idInput = document.getElementById("id") as HTMLInputElement;
    const nameInput = document.getElementById("name") as HTMLInputElement;
    const emailInput = document.getElementById("email") as HTMLInputElement;
    idInput.value = contacts[index].id;
    nameInput.value = contacts[index].name;
    emailInput.value = contacts[index].email;
}
import { gunretUniqueId } from "./util";
import { Contact } from "./contact";

export function addContact(name:string, email:string, contacts : Contact[]): void{
    const id = gunretUniqueId();
    const newContact = new Contact(name, email, id);
    contacts.push(newContact);
}
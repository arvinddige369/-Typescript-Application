import { Contact } from "./contact";
export function saveContact (contacts : Contact[]): void{
    localStorage.setItem("contacts",JSON.stringify(contacts));

}

export function readContact() : Contact[] {
const contacts=JSON.parse(localStorage.getItem("contacts")!);
if(contacts!= null){
    return contacts;
}
return[];
}